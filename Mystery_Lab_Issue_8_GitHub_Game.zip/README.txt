MYSTERY LAB: THE ROBOT REPAIR GARAGE

GITHUB PAGES SETUP
1. Unzip this download on your computer.
2. Create a new GitHub repository. Make it public if you plan to use GitHub Pages on a free account.
3. Open the repository, choose Add file > Upload files, and upload index.html, data.js, and the entire assets folder. Keep the folder structure intact. index.html must be at the top level of the repository.
4. Open Settings > Pages. Under Build and deployment, choose Deploy from a branch, select the main branch and / (root), and save.
5. Wait a few minutes, then return to Settings > Pages for the published link. Share that link with students. GitHub Pages publishes the files; students' browsers provide the voice.

HOW TO PLAY
Click Read this page to start narration. When you choose a button, the next page is read aloud automatically. Use Stop reading, Voice, or Speed as needed. Browser and device voices vary. Some devices may restrict automatic speech; if a page is silent, press Read this page. Students can play without sound. The game saves completed repairs in the current browser on that device. Restart on the last page clears the repair count.

This version retains the original choices and illustrations and presents slide text as accessible web text. Circuit labels are presented as text; original circuit diagram line art is not reproduced. On the original slides, students are told to repair at least two systems, but the Maker Fair scene says all four are working. This version preserves that wording.
