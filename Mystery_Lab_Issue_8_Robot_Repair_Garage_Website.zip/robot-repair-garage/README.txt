MYSTERY LAB ISSUE 8: THE ROBOT REPAIR GARAGE  (website version)
TEKS 5.8B choose-your-path mission. 19 slides, 16 pictures.

WHAT THIS IS
A plain website (no accounts, no tracking, nothing sent anywhere). It works in any browser, including student iPads. Students can play on their own, or you can project it for the whole class and vote on each choice.

WHAT'S IN THE FOLDER
  index.html   the page
  style.css    the look
  app.js       the story, the circuit drawings, and the buttons
  images/      the 16 pictures (about 3 MB in all)
  .nojekyll, _headers, netlify.toml   small helper files for GitHub Pages and Netlify (leave them in)

PROGRESS AND PRIVACY
The page remembers which systems a student has repaired, but only inside that one device's browser. Nothing is collected. The "Start over and clear progress" link at the bottom resets it. The Mission Report button unlocks after two repairs. For a projector or a teacher preview, add ?unlock=1 to the web address, like this:
  https://YOUR-ADDRESS/robot-repair-garage/?unlock=1

------------------------------------------------------------
OPTION 1: GITHUB PAGES (recommended, free, no credits)
------------------------------------------------------------
1. Unzip this file. You will get a folder named robot-repair-garage.
2. Go to your public GitHub repository (the one you made for your site).
3. Click Add file > Upload files.
4. Drag the whole robot-repair-garage folder into the box (Chrome or Edge work best; Safari may need you to open the folder and drag in the files and the images folder separately, keeping index.html and the images folder together).
5. Scroll down and click Commit changes.
6. First time only: open Settings > Pages. Under "Build and deployment", set Source to "Deploy from a branch", choose your main branch and the (root) folder, and click Save.
7. Wait one or two minutes. Your page will be at:
     https://YOUR-USERNAME.github.io/YOUR-REPO-NAME/robot-repair-garage/
   (If your repo is named YOUR-USERNAME.github.io, leave out the repo name.)
8. To change something later, edit or re-upload the file on GitHub and commit. There is no charge for updates.

------------------------------------------------------------
OPTION 2: NETLIFY (drag and drop)
------------------------------------------------------------
1. Unzip this file.
2. Go to https://app.netlify.com/drop and sign in.
3. Drag the robot-repair-garage folder onto the page. In a few seconds you get a link ending in .netlify.app.
4. To rename the link: Site configuration > Change site name.

Netlify tips:
- Each time you publish a new version, it uses 15 credits from your monthly pool. Publish once, and batch your changes.
- On the free plan, if your credits run out, ALL of your Netlify sites pause until the next month.
- Do not connect this folder to a GitHub repo on Netlify unless you want an automatic deploy (and 15 credits) every time you save a change on GitHub.

------------------------------------------------------------
PUTTING IT IN CANVAS
------------------------------------------------------------
Modules > + (plus) > External URL > paste your link > check "Load in a new tab" > Add Item. Students click through, as they do for your other assignments.

BEFORE YOU USE IT WITH STUDENTS
Open the link on a student iPad on your school network first. Some districts block certain websites, and you want to find out before class.

TO CHANGE TEXT OR CHOICES
The story text lives in app.js. If you would like to change wording, pictures, or choices, send me what you want changed and I will update the files.
