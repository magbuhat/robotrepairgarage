(function () {
  "use strict";

  // ---------- settings and saved progress ----------
  var UNLOCK = /[?&]unlock=1/.test(location.search); // teacher shortcut: ?unlock=1 opens the Mission Report
  var STORE = "mlRobotRepairGarageProgress";
  var state = { fixed: {} };
  try { var saved = localStorage.getItem(STORE); if (saved) state = JSON.parse(saved) || state; } catch (e) {}
  if (!state.fixed) state.fixed = {};
  function save() { try { localStorage.setItem(STORE, JSON.stringify(state)); } catch (e) {} }

  // ---------- colors and icons ----------
  var WHO = { "Maya": "#c2185b", "Diego": "#1565c0", "Priya": "#6a1b9a", "Dr. Park": "#00796b", "Sparky": "#e65100", "Principal": "#546e7a", "Mr. Reyes": "#6d4c41" };
  var OUT = {
    LIGHT: { color: "#fff176", label: "LED", badge: "#fff9c4" },
    SOUND: { color: "#ce93d8", label: "BUZZER", badge: "#ab47bc" },
    MOTION: { color: "#90caf9", label: "MOTOR", badge: "#42a5f5" },
    HEAT: { color: "#ffab91", label: "HEATER", badge: "#ff7043" }
  };
  var BADGE = { CHEMICAL: "#66bb6a", ELECTRICAL: "#ffd600", LIGHT: "#fff9c4", SOUND: "#ab47bc", MOTION: "#42a5f5", HEAT: "#ff7043" };
  var INK = "#1b2a41";
  var uid = 0;

  function glyph(type, cx, cy) {
    var g = '<g transform="translate(' + (cx - 20) + ' ' + (cy - 20) + ')">';
    if (type === "ELECTRICAL") g += '<polygon points="23,3 9,23 19,23 15,37 31,15 21,15" fill="' + INK + '"/>';
    if (type === "LIGHT") {
      g += '<circle cx="20" cy="20" r="7" fill="#ffb300" stroke="' + INK + '" stroke-width="1.5"/>';
      for (var i = 0; i < 8; i++) g += '<line x1="20" y1="5" x2="20" y2="10" stroke="#ffb300" stroke-width="3" stroke-linecap="round" transform="rotate(' + (i * 45) + ' 20 20)"/>';
    }
    if (type === "SOUND") g += '<g fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"><path d="M13 14 Q8 20 13 26"/><path d="M19 9 Q9 20 19 31"/><path d="M26 4 Q10 20 26 36"/></g>';
    if (type === "MOTION") {
      g += '<circle cx="20" cy="20" r="9" fill="#fff"/>';
      for (var j = 0; j < 8; j++) g += '<rect x="17" y="4" width="6" height="8" fill="#fff" transform="rotate(' + (j * 45) + ' 20 20)"/>';
      g += '<circle cx="20" cy="20" r="3.5" fill="' + BADGE.MOTION + '"/>';
    }
    if (type === "HEAT") g += '<path d="M20 3 C27 12 33 16 31 26 C29 35 11 35 9 26 C7 18 16 15 20 3Z" fill="#fff" stroke="' + INK + '" stroke-width="1"/>';
    if (type === "CHEMICAL") g += '<path d="M15 5 H25 V15 L33 32 H7 L15 15 Z" fill="#fff" stroke="' + INK + '" stroke-width="1"/><circle cx="17" cy="26" r="2" fill="' + BADGE.CHEMICAL + '"/><circle cx="23" cy="23" r="1.6" fill="' + BADGE.CHEMICAL + '"/>';
    return g + "</g>";
  }

  function chainSVG(types, label) {
    var id = "c" + (++uid), n = types.length, gap = 190, W = gap * (n - 1) + 170, H = 112, i;
    var s = '<svg class="chain" viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="' + label + '"><defs><marker id="' + id + '" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="' + INK + '"/></marker></defs>';
    for (i = 0; i < n; i++) {
      var cx = 85 + i * gap, cy = 42;
      s += '<circle cx="' + cx + '" cy="' + cy + '" r="31" fill="' + BADGE[types[i]] + '" stroke="' + INK + '" stroke-width="2.5"/>' + glyph(types[i], cx, cy);
      s += '<text x="' + cx + '" y="97" text-anchor="middle" font-size="13" font-weight="800" fill="' + INK + '">' + types[i] + "</text>";
    }
    for (i = 0; i < n - 1; i++) {
      var x1 = 85 + i * gap + 42, x2 = 85 + (i + 1) * gap - 44;
      s += '<line x1="' + x1 + '" y1="42" x2="' + x2 + '" y2="42" stroke="' + INK + '" stroke-width="4" marker-end="url(#' + id + ')"/>';
    }
    return s + "</svg>";
  }

  // circuit options: out, source (ok|missing|big), load (ok|missing|wire|two|big), gap, sw (closed|open), arrows, labels, stopArrow
  function circuitSVG(o, label) {
    var id = "m" + (++uid), out = OUT[o.out] || OUT.LIGHT;
    var xl = 130, xr = 570, yt = 72, yb = 206, mid = 139, swL = 372, swR = 462, gL = 205, gR = 275;
    var s = '<svg class="circuit" viewBox="0 0 700 270" role="img" aria-label="' + label + '"><defs><marker id="' + id + '" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="' + INK + '"/></marker></defs>';
    // wires
    var w = '<g stroke="#37474f" stroke-width="4" stroke-linecap="round" fill="none">';
    w += '<path d="M' + xl + ' ' + yt + 'V94"/><path d="M' + xl + ' 184V' + yb + '"/>';
    if (o.load === "wire") w += '<path d="M' + xr + " " + yt + "V" + yb + '"/>';
    else w += '<path d="M' + xr + " " + yt + 'V94"/><path d="M' + xr + " 184V" + yb + '"/>';
    w += '<path d="M' + xl + " " + yb + "H" + xr + '"/>';
    if (o.gap) w += '<path d="M' + xl + " " + yt + "H" + gL + '"/><path d="M' + gR + " " + yt + "H" + swL + '"/>';
    else w += '<path d="M' + xl + " " + yt + "H" + swL + '"/>';
    w += '<path d="M' + swR + " " + yt + "H" + xr + '"/></g>';
    s += w;
    // switch
    if (o.sw === "open") {
      s += '<circle cx="' + swL + '" cy="' + yt + '" r="6" fill="#37474f"/><circle cx="' + swR + '" cy="' + yt + '" r="6" fill="#37474f"/>';
      s += '<line x1="' + swL + '" y1="' + yt + '" x2="' + (swL + 72) + '" y2="' + (yt - 46) + '" stroke="#c62828" stroke-width="6" stroke-linecap="round"/>';
      s += '<text x="' + ((swL + swR) / 2) + '" y="' + (yt + 34) + '" text-anchor="middle" font-size="15" font-weight="800" fill="#c62828">SWITCH: OPEN</text>';
    } else {
      s += '<rect x="' + swL + '" y="' + (yt - 17) + '" width="90" height="34" rx="8" fill="#a5d6a7" stroke="#2e7d32" stroke-width="2.5"/><text x="' + ((swL + swR) / 2) + '" y="' + (yt + 5) + '" text-anchor="middle" font-size="13" font-weight="800" fill="' + INK + '">SWITCH</text>';
    }
    // gap marker
    if (o.gap) {
      s += '<ellipse cx="' + ((gL + gR) / 2) + '" cy="' + yt + '" rx="48" ry="26" fill="none" stroke="#c62828" stroke-width="3" stroke-dasharray="7 5"/>';
      s += '<text x="' + ((gL + gR) / 2) + '" y="' + (yt - 36) + '" text-anchor="middle" font-size="16" font-weight="800" fill="#c62828">GAP</text>';
    }
    // battery
    if (o.source === "missing") {
      s += '<rect x="80" y="94" width="100" height="90" fill="#fff" stroke="#c62828" stroke-width="3" stroke-dasharray="7 5"/><text x="130" y="145" text-anchor="middle" font-size="36" font-weight="900" fill="#c62828">?</text><text x="130" y="170" text-anchor="middle" font-size="13" font-weight="800" fill="#c62828">EMPTY</text>';
    } else {
      var bname = o.labels ? "SOURCE" : (o.source === "big" ? "BIGGER" : "BATTERY");
      s += '<rect x="80" y="94" width="100" height="90" fill="' + (o.source === "big" ? "#ffb74d" : "#81c784") + '" stroke="' + INK + '" stroke-width="2.5"/>';
      s += '<text x="130" y="118" text-anchor="middle" font-size="20" font-weight="900" fill="' + INK + '">+</text><text x="130" y="142" text-anchor="middle" font-size="13" font-weight="800" fill="' + INK + '">' + bname + "</text>";
      if (o.source === "big" && !o.labels) s += '<text x="130" y="158" text-anchor="middle" font-size="13" font-weight="800" fill="' + INK + '">BATTERY</text>';
      s += '<text x="130" y="178" text-anchor="middle" font-size="20" font-weight="900" fill="' + INK + '">\u2013</text>';
    }
    // load
    if (o.load === "missing") {
      s += '<rect x="520" y="94" width="100" height="90" fill="#fff" stroke="#c62828" stroke-width="3" stroke-dasharray="7 5"/><text x="570" y="145" text-anchor="middle" font-size="36" font-weight="900" fill="#c62828">?</text><text x="570" y="170" text-anchor="middle" font-size="13" font-weight="800" fill="#c62828">NO LOAD</text>';
    } else if (o.load === "wire") {
      s += '<text x="582" y="143" font-size="13" font-weight="800" fill="#c62828">ONLY</text><text x="582" y="160" font-size="13" font-weight="800" fill="#c62828">WIRE</text>';
    } else if (o.load === "two") {
      s += '<rect x="520" y="90" width="100" height="44" fill="' + out.color + '" stroke="' + INK + '" stroke-width="2.5"/><text x="570" y="118" text-anchor="middle" font-size="13" font-weight="800" fill="' + INK + '">' + out.label + '</text>';
      s += '<rect x="520" y="140" width="100" height="44" fill="' + out.color + '" stroke="' + INK + '" stroke-width="2.5"/><text x="570" y="168" text-anchor="middle" font-size="13" font-weight="800" fill="' + INK + '">' + out.label + ' 2</text>';
    } else {
      var big = o.load === "big", lx = big ? 505 : 520, lw = big ? 130 : 100, ly = big ? 84 : 94, lh = big ? 110 : 90;
      var lname = o.labels ? "LOAD" : (big ? "BIGGER " + out.label : out.label);
      s += '<rect x="' + lx + '" y="' + ly + '" width="' + lw + '" height="' + lh + '" fill="' + out.color + '" stroke="' + INK + '" stroke-width="2.5"/><text x="570" y="144" text-anchor="middle" font-size="15" font-weight="800" fill="' + INK + '">' + lname + "</text>";
    }
    if (o.labels) s += '<text x="240" y="244" text-anchor="middle" font-size="14" font-weight="800" fill="' + INK + '">CONDUCTOR (wire)</text>';
    // arrows
    if (o.arrows) {
      s += '<line x1="170" y1="40" x2="300" y2="40" stroke="' + INK + '" stroke-width="5" marker-end="url(#' + id + ')"/>';
      s += '<line x1="520" y1="238" x2="390" y2="238" stroke="' + INK + '" stroke-width="5" marker-end="url(#' + id + ')"/>';
    }
    if (o.stopArrow) s += '<line x1="140" y1="40" x2="190" y2="40" stroke="' + INK + '" stroke-width="5" marker-end="url(#' + id + ')"/>';
    return s + "</svg>";
  }

  // ---------- slide content ----------
  var PATHS = [
    { key: "eyes", out: "LIGHT", d: 5, r: 6, f: 7, name: "Eyes", t: "EYES", hubLabel: "Eyes (light)", letter: "A",
      alt: ["Close-up of Sparky's open eye panel with a loose wire while Maya and Diego look closely.", "Sparky's eyes glow yellow while Maya and Diego cheer."],
      dBub: [["Maya", "Sparky\u2019s eyes are LEDs. The battery is fine and the switch is on."], ["Diego", "But look! One wire came unplugged."]],
      q: "What does the eye circuit need?", A: "A: Close the gap", B: "B: Add a bigger battery",
      dCirc: { out: "LIGHT", source: "ok", load: "ok", gap: true, sw: "closed" }, dLabel: "Eye circuit with a gap in the top wire.",
      rCirc: { out: "LIGHT", source: "big", load: "ok", gap: true, sw: "closed", stopArrow: true }, rLabel: "A bigger battery, but the gap is still there.",
      rBub: [["Diego", "A bigger battery, and the eyes are still dark!"], ["Dr. Park", "REPLAY: Extra energy can\u2019t cross a gap. A circuit needs a complete path."], ["Priya", "Let\u2019s close the gap instead."]],
      fBub: [["Maya", "Sparky can see again!"], ["Dr. Park", "The load changed electrical energy into light."]],
      check: ["SOURCE: battery", "CONDUCTOR: complete path", "LOAD: LED", "SWITCH: on"] },
    { key: "voice", out: "SOUND", d: 8, r: 9, f: 10, name: "Voice", t: "VOICE", hubLabel: "Voice (sound)", letter: "B",
      alt: ["Sparky's open mouth panel with an empty socket while Priya points and Diego holds a flashlight.", "Sparky speaks happily with sound ripples while Priya and Maya wave."],
      dBub: [["Priya", "Sparky\u2019s voice circuit has a battery, wires, and a closed switch."], ["Diego", "But where is the buzzer?"]],
      q: "What does the voice circuit need?", A: "A: Add a buzzer", B: "B: Add more wire",
      dCirc: { out: "SOUND", source: "ok", load: "missing", sw: "closed" }, dLabel: "Voice circuit with the load missing.",
      rCirc: { out: "SOUND", source: "ok", load: "wire", sw: "closed" }, rLabel: "Plain wire where the load should be.",
      rBub: [["Diego", "We added more wire, and he is still silent."], ["Dr. Park", "REPLAY: Wire only carries energy. A load changes it into sound. Never connect a battery to only wire, because that is a short circuit and can get hot!"], ["Priya", "Let\u2019s add the buzzer."]],
      fBub: [["Sparky", "Hello, Mystery Lab!"], ["Dr. Park", "The load changed electrical energy into sound."]],
      check: ["SOURCE: battery", "CONDUCTOR: complete path", "LOAD: buzzer", "SWITCH: on"] },
    { key: "arms", out: "MOTION", d: 11, r: 12, f: 13, name: "Arms", t: "ARMS", hubLabel: "Arms (motion)", letter: "C",
      alt: ["Sparky's open shoulder panel with a tiny motor and an empty battery slot.", "Sparky waves his arm while Diego waves back and Maya claps."],
      dBub: [["Maya", "The motor, the wires, and the switch are all connected."], ["Diego", "But the battery slot is empty!"]],
      q: "What does the arm circuit need?", A: "A: Add a battery", B: "B: Add a second motor",
      dCirc: { out: "MOTION", source: "missing", load: "ok", sw: "closed" }, dLabel: "Arm circuit with the battery missing.",
      rCirc: { out: "MOTION", source: "missing", load: "two", sw: "closed" }, rLabel: "Two motors, but still no battery.",
      rBub: [["Maya", "Two motors, and neither one moves."], ["Dr. Park", "REPLAY: More loads can\u2019t help without a source. No source means no energy."], ["Diego", "Time to find a battery!"]],
      fBub: [["Diego", "Sparky is waving!"], ["Dr. Park", "The load changed electrical energy into motion."]],
      check: ["SOURCE: battery", "CONDUCTOR: complete path", "LOAD: motor", "SWITCH: on"] },
    { key: "heat", out: "HEAT", d: 14, r: 15, f: 16, name: "Chest warmer", t: "WARMER", hubLabel: "Chest warmer (heat)", letter: "D",
      alt: ["Sparky's cold, frosty chest panel with a heater plate and a switch while Maya shivers in a scarf and Priya holds a clipboard.", "Sparky's chest panel glows warm orange while the kids hold their hands near it without touching."],
      dBub: [["Priya", "The battery, the wires, and the heater are all connected."], ["Maya", "But the switch is open."]],
      q: "What does the chest circuit need?", A: "A: Close the switch", B: "B: Add a bigger heater",
      dCirc: { out: "HEAT", source: "ok", load: "ok", sw: "open" }, dLabel: "Chest circuit with the switch open.",
      rCirc: { out: "HEAT", source: "ok", load: "big", sw: "open" }, rLabel: "A bigger heater, but the switch is still open.",
      rBub: [["Diego", "A bigger heater, and the panel is still cold!"], ["Dr. Park", "REPLAY: An open switch means an open path. Close the switch to complete it."], ["Maya", "Let\u2019s close the switch."]],
      fBub: [["Maya", "The panel is warming up!"], ["Dr. Park", "The load changed electrical energy into heat. Never touch a heater to test it. Hold your hand near it."]],
      check: ["SOURCE: battery", "CONDUCTOR: complete path", "LOAD: heater", "SWITCH: closed"] }
  ];

  var S = {};
  function add(n, o) { o.n = n; S[n] = o; }

  add(1, { kind: "cover", title: "COVER", img: "slide01.jpg", alt: "The Mystery Lab turned into a Robot Repair Garage. Maya, Diego, Priya, Dr. Park, and Newt gather around Sparky, a friendly robot who is powered off.", buttons: [{ label: "START", to: 2, tone: "NEXT" }] });
  add(2, { kind: "story", title: "SPARKY ARRIVES", img: "slide02.jpg", alt: "Sparky the robot sits slumped and dark on the workbench. Maya, Diego, Priya, and Dr. Park look worried.", bubbles: [["Dr. Park", "The Maker Fair starts tonight, and our greeter robot, Sparky, just stopped working!"], ["Maya", "Poor Sparky! Can we fix him?"], ["Diego", "His eyes are dark, he is silent, his arms will not move, and his chest panel is cold!"], ["Priya", "Four systems, four circuits. Let\u2019s find out what each one needs."]], caption: "THE MISSION: Repair Sparky before the Maker Fair!", buttons: [{ label: "NEXT", to: 3, tone: "NEXT" }] });
  add(3, { kind: "req", title: "WHAT A CIRCUIT NEEDS", img: "slide03.jpg", alt: "Dr. Park stands at a blank whiteboard while Maya and Priya listen and Sparky rests on the bench.", bubbles: [["Dr. Park", "Every working circuit needs four things. Fixing Sparky means finding which one is missing."]], buttons: [{ label: "NEXT", to: 4, tone: "NEXT" }] });
  add(4, { kind: "hub", title: "THE REPAIR HUB", img: "slide04.jpg", alt: "Sparky lies on the workbench with four panels open while the team stands around him with tools.", bubbles: [["Priya", "Which system should we repair?"], ["Dr. Park", "Repair at least two before the fair!"]], caption: "THE CLASS DECIDES: Which system do we repair?" });

  PATHS.forEach(function (P) {
    add(P.d, { kind: "diag", title: P.t + ": WHAT\u2019S WRONG?", img: "slide" + pad(P.d) + ".jpg", alt: P.alt[0], circ: P.dCirc, circLabel: P.dLabel, bubbles: P.dBub, caption: "THE CLASS DECIDES: " + P.q, buttons: [{ label: P.A, to: P.f, tone: "A" }, { label: P.B, to: P.r, tone: "B" }] });
    add(P.r, { kind: "replay", title: "REPLAY: " + P.t, img: "slide06.jpg", alt: "Dr. Park holds a pause remote in front of a big screen while Maya, Diego, and Priya watch with surprise.", circ: P.rCirc, circLabel: P.rLabel, bubbles: P.rBub, buttons: [{ label: "TRY AGAIN", to: P.d, tone: "TRY" }] });
    add(P.f, { kind: "fixed", title: P.t + " FIXED!", img: "slide" + pad(P.f) + ".jpg", alt: P.alt[1], out: P.out, sys: P.key, bubbles: P.fBub, check: P.check, buttons: [{ label: "BACK TO THE REPAIR HUB", to: 4, tone: "HUB" }] });
  });

  add(17, { kind: "report", title: "MISSION REPORT", img: "slide17.jpg", alt: "Dr. Park holds a clipboard with a gold star beside a smiling Sparky while the kids give thumbs-up.", bubbles: [["Priya", "Every working circuit needs a source, a conductor in a complete path, and a load."], ["Maya", "And a switch to open and close the path!"]], buttons: [{ label: "NEXT", to: 18, tone: "NEXT" }] });
  add(18, { kind: "story", title: "THE MAKER FAIR", img: "slide18.jpg", alt: "At the Maker Fair, Sparky waves at the entrance beside the Principal, Mr. Reyes, Dr. Park, and the three kids.", bubbles: [["Sparky", "Welcome to the Maker Fair!"], ["Principal", "The Mystery Lab fixed our greeter robot!"], ["Mr. Reyes", "All four systems work. How did you do it?"], ["Dr. Park", "They found what each circuit needed, and they made smart choices."]], caption: "Case closed! To be continued\u2026 in the next case!", buttons: [{ label: "NEXT", to: 19, tone: "NEXT" }] });
  add(19, { kind: "exit", title: "EXIT QUESTIONS", img: "slide19.jpg", alt: "Priya sits at the repair bench with a clipboard and pencil beside a smiling Sparky.", buttons: [{ label: "RESTART", to: 1, tone: "NEXT", restart: true }] });

  var FIXED_AT = { 7: "eyes", 10: "voice", 13: "arms", 16: "heat" };
  var TOTAL = 19;

  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function esc(t) { return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }

  // ---------- builders ----------
  function sceneHTML(s, tag) {
    return '<figure class="scene"><img src="images/' + s.img + '" alt="' + esc(s.alt) + '" width="1200" height="800" decoding="async">' + (tag ? '<span class="tag">' + tag + "</span>" : "") + "</figure>";
  }
  function bubblesHTML(list) {
    if (!list) return "";
    return '<div class="bubbles">' + list.map(function (b) { return '<div class="bubble" style="--c:' + (WHO[b[0]] || "#12234a") + '"><span class="who">' + esc(b[0]) + "</span><p>" + esc(b[1]) + "</p></div>"; }).join("") + "</div>";
  }
  function captionHTML(t) { return t ? '<div class="caption">' + esc(t) + "</div>" : ""; }
  function checksHTML(items) { return '<div class="checks">' + items.map(function (i) { return '<div class="chip">' + esc(i) + "</div>"; }).join("") + "</div>"; }

  function fixedCount() { return ["eyes", "voice", "arms", "heat"].filter(function (k) { return state.fixed[k]; }).length; }

  function buildMain(s) {
    var h = "";
    if (s.kind === "cover") {
      h += sceneHTML(s) + '<div class="cover"><div class="titleblock"><div class="big">MYSTERY LAB</div><div class="issue">ISSUE 8: THE ROBOT REPAIR GARAGE</div><div class="sub">A Choose-Your-Path Mission</div><div class="quote">\u201CYou decide. The circuit tells the truth.\u201D</div><div class="cast">Maya \u00B7 Diego \u00B7 Priya \u00B7 Newt \u00B7 Dr. Park \u00B7 Sparky \u00B7 YOU</div></div></div>';
    } else if (s.kind === "req") {
      h += sceneHTML(s);
      h += '<div class="diagram">' + circuitSVG({ out: "LIGHT", source: "ok", load: "ok", sw: "closed", arrows: true, labels: true }, "A working circuit loop. The top arrow points right and the bottom arrow points left.") + "</div>";
      h += '<div class="needs">' + [["1  SOURCE", "gives the energy (a battery)", "#2e7d32"], ["2  CONDUCTOR", "makes a complete path (wire or tape)", "#455a64"], ["3  LOAD", "changes the energy (LED, buzzer, motor, heater)", "#6a1b9a"], ["4  SWITCH", "opens and closes the path", "#c75d00"]].map(function (r) { return '<div class="need"><b style="background:' + r[2] + '">' + r[0] + "</b><span>" + r[1] + "</span></div>"; }).join("") + "</div>";
      h += bubblesHTML(s.bubbles);
    } else if (s.kind === "hub") {
      h += sceneHTML(s) + bubblesHTML(s.bubbles) + captionHTML(s.caption);
      h += '<div class="status" aria-label="Repair progress"><span>Repaired: ' + fixedCount() + " of 4</span>" + PATHS.map(function (P) { return '<span class="pill' + (state.fixed[P.key] ? " done" : "") + '">' + (state.fixed[P.key] ? "\u2713 " : "") + P.name + "</span>"; }).join("") + "</div>";
    } else if (s.kind === "diag" || s.kind === "replay") {
      h += sceneHTML(s, s.kind === "replay" ? "REPLAY" : "");
      h += '<div class="diagram">' + circuitSVG(s.circ, s.circLabel) + "</div>";
      h += bubblesHTML(s.bubbles) + captionHTML(s.caption);
    } else if (s.kind === "fixed") {
      h += sceneHTML(s);
      h += '<div class="diagram">' + circuitSVG({ out: s.out, source: "ok", load: "ok", sw: "closed", arrows: true }, "The working circuit. The top arrow points right and the bottom arrow points left.") + "</div>";
      h += '<div class="chainwrap">' + chainSVG(["ELECTRICAL", s.out], "Energy chain: electrical energy changes into " + s.out.toLowerCase() + " energy. The arrow points right.") + "</div>";
      h += checksHTML(s.check) + bubblesHTML(s.bubbles);
    } else if (s.kind === "report") {
      h += sceneHTML(s);
      h += '<h2 class="h3">WHAT EVERY WORKING CIRCUIT NEEDS</h2><div class="needs">' + [["SOURCE", "gives energy (a battery)", "#2e7d32"], ["CONDUCTOR", "makes a complete path", "#455a64"], ["LOAD", "changes the energy", "#6a1b9a"], ["SWITCH (bonus)", "opens and closes the path", "#c75d00"]].map(function (r) { return '<div class="need"><b style="background:' + r[2] + '">' + r[0] + "</b><span>" + r[1] + "</span></div>"; }).join("") + "</div>";
      h += '<h2 class="h3">ONE CIRCUIT, FOUR OUTPUTS</h2><div class="grid4">' + ["LIGHT", "SOUND", "MOTION", "HEAT"].map(function (o) { return chainSVG(["ELECTRICAL", o], "Electrical energy changes into " + o.toLowerCase() + " energy. The arrow points right."); }).join("") + "</div>";
      h += bubblesHTML(s.bubbles);
    } else if (s.kind === "exit") {
      h += sceneHTML(s);
      h += '<div class="exitcard"><h2>EXIT QUESTIONS</h2><ol><li>What three things does every working circuit need?</li><li>What happens if there is a gap in the path?</li><li>Choose one output (light, sound, motion, or heat). What did electrical energy change into?</li></ol></div>';
    } else {
      h += sceneHTML(s) + bubblesHTML(s.bubbles) + captionHTML(s.caption);
    }
    return h;
  }

  function buildActions(s) {
    var box = document.getElementById("actions");
    var html = "", cls = "actions";
    if (s.kind === "hub") {
      cls += " hub";
      PATHS.forEach(function (P) {
        html += '<button class="btn tone-' + P.letter.replace(/[^A-E]/g, "") + '" data-to="' + P.d + '">' + P.letter + ": " + esc(P.hubLabel) + (state.fixed[P.key] ? " \u2713" : "") + "</button>";
      });
      var open = UNLOCK || fixedCount() >= 2;
      html += '<button class="btn tone-E span2" data-to="17"' + (open ? "" : ' disabled aria-disabled="true"') + ">E: Mission Report" + (open ? "" : " (repair 2 systems first)") + "</button>";
    } else {
      if (s.buttons.length === 2) cls += " two";
      html += s.buttons.map(function (b) { return '<button class="btn tone-' + b.tone + '" data-to="' + b.to + '"' + (b.restart ? ' data-restart="1"' : "") + ">" + esc(b.label) + "</button>"; }).join("");
    }
    box.className = cls;
    box.innerHTML = html;
  }

  // ---------- routing ----------
  function current() { var m = /#\/(\d+)/.exec(location.hash); var n = m ? parseInt(m[1], 10) : 1; return S[n] ? n : 1; }
  function go(n) { location.hash = "#/" + n; }

  function render() {
    var n = current(), s = S[n];
    if (FIXED_AT[n]) { state.fixed[FIXED_AT[n]] = true; save(); }
    document.getElementById("slidenum").textContent = "SLIDE " + n + " OF " + TOTAL;
    document.getElementById("slidetitle").textContent = s.title;
    document.title = "Slide " + n + ": " + s.title + " \u2013 Mystery Lab Issue 8";
    var main = document.getElementById("main");
    main.innerHTML = buildMain(s);
    buildActions(s);
    window.scrollTo(0, 0);
    try { main.focus({ preventScroll: true }); } catch (e) {}
  }

  function resetAll() { state = { fixed: {} }; save(); go(1); render(); }

  document.getElementById("actions").addEventListener("click", function (e) {
    var b = e.target.closest("button");
    if (!b || b.disabled) return;
    if (b.getAttribute("data-restart")) { state = { fixed: {} }; save(); }
    go(parseInt(b.getAttribute("data-to"), 10));
  });
  document.getElementById("reset").addEventListener("click", resetAll);
  window.addEventListener("hashchange", render);
  render();
})();
